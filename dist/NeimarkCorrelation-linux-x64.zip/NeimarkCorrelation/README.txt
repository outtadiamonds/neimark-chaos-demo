Осциллятор Неймарка: построение корреляционной функции
Компьютерная демонстрация по курсу «Статистическая физика», ВМК МГУ.

Запуск: распакуйте архив и запустите файл NeimarkCorrelation в папке программы
(двойной щелчок или в терминале: ./NeimarkCorrelation).
Ничего устанавливать не нужно. Требуется 64-битный Linux (x86-64) с графическим
окружением (X11 или Wayland) и glibc 2.31 или новее (Ubuntu 20.04+, Debian 11+,
Fedora 32+, Astra Linux 1.7+ и т. п.).
Если файл не запускается, сделайте его исполняемым: chmod +x NeimarkCorrelation

Теория: theory_ru.pdf (на русском), theory_en.pdf (in English).
Язык интерфейса переключается кнопкой English/Русский. F11 — полноэкранный режим.

----
Neimark oscillator: building the correlation function
Unpack and run ./NeimarkCorrelation. Nothing needs to be installed
(x86-64 Linux with a graphical session, glibc 2.31 or newer).
